package com.example.hangmanttn.game

import androidx.compose.foundation.Image
import androidx.compose.foundation.R
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme.colorScheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

@Composable
private fun GallowsImage(resId: Int, modifier: Modifier = Modifier, tint: Color = Color.Black) {
    Image(
        painter = painterResource(resId),
        contentDescription = null,
        colorFilter = ColorFilter.tint(tint),
        modifier = modifier.fillMaxWidth()
    )
}

@Composable
private fun GuessWordText(word: String, modifier: Modifier = Modifier) {
    Text(
        text = word.uppercase(Locale.getDefault()),
        textAlign = TextAlign.Center,
        fontWeight = FontWeight.Bold,
        letterSpacing = 8.sp,
        modifier = modifier.fillMaxWidth()
    )
}

@Composable
private fun UsedLettersText(usedLetters: String, modifier: Modifier) {
    Column {
        Text(
            text = stringResource(R.string.used_letters),
            textAlign = TextAlign.Left,
            fontWeight = FontWeight.Light,
            color = colorScheme.primary,
            modifier = modifier.fillMaxWidth()
        )
        Text(
            text = usedLetters.uppercase(Locale.getDefault()),
            textAlign = TextAlign.Left,
            fontWeight = FontWeight.Light,
            color = colorScheme.primary,
            modifier = modifier.fillMaxWidth()
        )
    }
}

@Composable
fun LetterInputField(
    buttonText: String,
    buttonEnabled: Boolean,
    isError: Boolean,
    onButtonClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.Center,
    ) {
        TextField(
            value = "",
            onValueChange = { },
            singleLine = true,
            shape = RoundedCornerShape(topStart = 8.dp, bottomStart = 8.dp),
            label = {Text(text = stringResource(R.string.enter_letter))},
            isError = isError
        )

        Button(
            onClick = onButtonClick,
            enabled = buttonEnabled,
            shape = RoundedCornerShape(
                topStart = 0.dp,
                topEnd = 8.dp,
                bottomStart = 0.dp,
                bottomEnd = 8.dp
            ),
            modifier = Modifier
                .defaultMinSize(minHeight = TextFieldDefaults.MinHeight)
        ) {
            Text(text = buttonText)
        }
    }
}